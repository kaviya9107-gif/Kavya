<?php
/**
 * On-Screen help tab: Bulk Actions.
 *
 * @package    RankMath
 * @subpackage RankMath\Redirections
 */

defined( 'ABSPATH' ) || exit;

?>
<p>
	<?php esc_html_e( 'You can also activate, deactivate, or delete multiple items at once using the Bulk Actions dropdown.', 'seo-by-rank-math' ); ?>
</p>
